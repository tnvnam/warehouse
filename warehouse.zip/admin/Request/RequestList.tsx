import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  FlatList,
  StyleSheet,
  ActivityIndicator,
  TouchableOpacity,
  Alert,
} from 'react-native';
import Ionicons from 'react-native-vector-icons/Ionicons';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { RootStackParamList } from '../AppNavigator';

type NavigationProp = NativeStackNavigationProp<RootStackParamList, 'RequestList'>;

interface RequestItem {
  id: string;
  type: 'import' | 'export';
  status: 'pending' | 'approved' | 'rejected';
  department_name: string;
  date: string;
}

const RequestList = () => {
  const [requests, setRequests] = useState<RequestItem[]>([]);
  const [loading, setLoading] = useState(true);
  const navigation = useNavigation<NavigationProp>();

  const fetchRequests = async () => {
    try {
      const res = await fetch('http://10.0.2.2:3000/requests');
      const data = await res.json();
      setRequests(data);
    } catch (err) {
      Alert.alert('Lỗi', 'Không thể tải danh sách yêu cầu');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchRequests();
  }, []);

  const translateStatus = (status: string) => {
    switch (status) {
      case 'pending': return 'Chờ duyệt';
      case 'approved': return 'Đã duyệt';
      case 'rejected': return 'Từ chối';
      default: return status;
    }
  };

  const renderItem = ({ item }: { item: RequestItem }) => (
    <TouchableOpacity
      style={styles.item}
      onPress={() => navigation.navigate('RequestDetail', { id: item.id })}
    >
      <Ionicons
        name={item.type === 'import' ? 'arrow-down-circle-outline' : 'arrow-up-circle-outline'}
        size={24}
        color={item.type === 'import' ? '#007bff' : 'orange'}
        style={styles.icon}
      />
      <View style={{ flex: 1 }}>
        <Text style={styles.title}>Phiếu {item.type === 'import' ? 'nhập' : 'xuất'} - {item.department_name}</Text>
        <Text style={styles.meta}>Ngày: {item.date} | Trạng thái: {translateStatus(item.status)}</Text>
      </View>
      <Ionicons name="chevron-forward" size={20} color="#888" />
    </TouchableOpacity>
  );

  if (loading) return <ActivityIndicator size="large" style={{ marginTop: 100 }} />;

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Danh sách phiếu yêu cầu</Text>
      <FlatList
        data={requests}
        keyExtractor={(item) => item.id}
        renderItem={renderItem}
      />
      <TouchableOpacity
        style={styles.addBtn}
        onPress={() => navigation.navigate('RequestForm')}
      >
        <Ionicons name="add" size={24} color="#fff" />
        <Text style={styles.addText}>Tạo yêu cầu</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff', padding: 16 },
  header: { fontSize: 20, fontWeight: 'bold', marginBottom: 12 },
  item: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f5f5f5',
    padding: 12,
    borderRadius: 8,
    marginBottom: 10,
  },
  icon: { marginRight: 12 },
  title: { fontWeight: '600', fontSize: 16 },
  meta: { color: '#555', fontSize: 13 },
  addBtn: {
    marginTop: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 12,
    borderRadius: 6,
    backgroundColor: '#28a745',
  },
  addText: { color: '#fff', marginLeft: 6, fontWeight: '600' },
});

export default RequestList;
