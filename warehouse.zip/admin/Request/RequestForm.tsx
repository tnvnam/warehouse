import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  Alert,
  ScrollView,
  StyleSheet,
} from 'react-native';
import Ionicons from 'react-native-vector-icons/Ionicons';
import { Picker } from '@react-native-picker/picker';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { RootStackParamList } from '../AppNavigator';

type NavigationProp = NativeStackNavigationProp<RootStackParamList, 'RequestForm'>;

interface Department {
  id: string;
  name: string;
}

interface Material {
  id: string;
  name: string;
}

const RequestForm = () => {
  const navigation = useNavigation<NavigationProp>();
  const [type, setType] = useState<'import' | 'export'>('import');
  const [departmentId, setDepartmentId] = useState('');
  const [materialId, setMaterialId] = useState('');
  const [quantity, setQuantity] = useState('');

  const [departments, setDepartments] = useState<Department[]>([]);
  const [materials, setMaterials] = useState<Material[]>([]);

  const fetchData = async () => {
    try {
      const [depRes, matRes] = await Promise.all([
        fetch('http://10.0.2.2:3000/departments'),
        fetch('http://10.0.2.2:3000/materials')
      ]);
      const depData = await depRes.json();
      const matData = await matRes.json();
      setDepartments(depData);
      setMaterials(matData);
    } catch {
      Alert.alert('Lỗi', 'Không thể tải dữ liệu');
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleSubmit = async () => {
    if (!departmentId || !materialId || !quantity) {
      Alert.alert('Thiếu thông tin', 'Vui lòng nhập đầy đủ');
      return;
    }

    try {
      const res = await fetch('http://10.0.2.2:3000/requests', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type,
          department_id: departmentId,
          items: [{ material_id: materialId, quantity: Number(quantity) }],
          status: 'pending'
        })
      });

      if (res.ok) {
        Alert.alert('Thành công', 'Đã tạo phiếu yêu cầu');
        navigation.goBack();
      } else {
        Alert.alert('Lỗi', 'Tạo phiếu thất bại');
      }
    } catch {
      Alert.alert('Lỗi', 'Không thể kết nối server');
    }
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.header}>Tạo phiếu yêu cầu</Text>

      <Text style={styles.label}>Loại phiếu</Text>
      <View style={styles.picker}>
        <Picker selectedValue={type} onValueChange={(val) => setType(val)}>
          <Picker.Item label="Nhập kho" value="import" />
          <Picker.Item label="Xuất kho" value="export" />
        </Picker>
      </View>

      <Text style={styles.label}>Phòng ban</Text>
      <View style={styles.picker}>
        <Picker selectedValue={departmentId} onValueChange={(val) => setDepartmentId(val)}>
          <Picker.Item label="-- Chọn --" value="" />
          {departments.map(d => (
            <Picker.Item label={d.name} value={d.id} key={d.id} />
          ))}
        </Picker>
      </View>

      <Text style={styles.label}>Nguyên vật liệu</Text>
      <View style={styles.picker}>
        <Picker selectedValue={materialId} onValueChange={(val) => setMaterialId(val)}>
          <Picker.Item label="-- Chọn --" value="" />
          {materials.map(m => (
            <Picker.Item label={m.name} value={m.id} key={m.id} />
          ))}
        </Picker>
      </View>

      <Text style={styles.label}>Số lượng</Text>
      <TextInput
        style={styles.input}
        keyboardType="numeric"
        value={quantity}
        onChangeText={setQuantity}
        placeholder="Nhập số lượng"
      />

      <TouchableOpacity style={styles.button} onPress={handleSubmit}>
        <Ionicons name="save" size={20} color="#fff" />
        <Text style={styles.buttonText}>Lưu yêu cầu</Text>
      </TouchableOpacity>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: { padding: 16, backgroundColor: '#fff' },
  header: { fontSize: 20, fontWeight: 'bold', marginBottom: 16 },
  label: { marginTop: 12, marginBottom: 4, fontWeight: '600' },
  picker: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 6,
    marginBottom: 10,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 6,
    padding: 10,
    marginBottom: 10,
  },
  button: {
    marginTop: 20,
    backgroundColor: '#007bff',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 12,
    borderRadius: 6,
  },
  buttonText: { color: '#fff', marginLeft: 6, fontWeight: '600' },
});

export default RequestForm;
