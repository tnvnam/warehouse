import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  FlatList,
  StyleSheet,
  ActivityIndicator,
  Alert,
  TextInput,
  TouchableOpacity,
} from 'react-native';
import Ionicons from 'react-native-vector-icons/Ionicons';
import { Picker } from '@react-native-picker/picker';
import DateTimePicker from '@react-native-community/datetimepicker';
import RNFS from 'react-native-fs';
import Share from 'react-native-share';
import { unparse } from 'papaparse';

interface ReportItem {
  material_name: string;
  warehouse_name: string;
  quantity: number;
  unit_name: string;
  min_level: number;
  max_level: number;
  expired: boolean;
}

interface Warehouse {
  id: string;
  name: string;
}

const InventoryReport = () => {
  const [data, setData] = useState<ReportItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
  const [warehouseId, setWarehouseId] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [fromDate, setFromDate] = useState(new Date());
  const [toDate, setToDate] = useState(new Date());

  const fetchWarehouses = async () => {
    try {
      const res = await fetch('http://10.0.2.2:3000/warehouses');
      const result = await res.json();
      setWarehouses(result);
    } catch {
      Alert.alert('Lỗi', 'Không thể tải kho');
    }
  };

  const fetchData = async () => {
    setLoading(true);
    const from = fromDate.toISOString().split('T')[0];
    const to = toDate.toISOString().split('T')[0];
    const query = `?from=${from}&to=${to}&warehouse_id=${warehouseId}&status=${statusFilter}`;

    try {
      const res = await fetch(`http://10.0.2.2:3000/inventory/report${query}`);
      const result = await res.json();
      setData(result);
    } catch {
      Alert.alert('Lỗi', 'Không thể tải dữ liệu báo cáo');
    } finally {
      setLoading(false);
    }
  };

  const exportCSV = async () => {
    if (data.length === 0) {
      Alert.alert('Không có dữ liệu để xuất');
      return;
    }

    const csv = unparse(data);
    const path = `${RNFS.DocumentDirectoryPath}/inventory_report.csv`;

    try {
      await RNFS.writeFile(path, csv, 'utf8');
      await Share.open({ url: 'file://' + path, type: 'text/csv' });
    } catch (error) {
      Alert.alert('Lỗi', 'Không thể xuất file CSV');
    }
  };

  useEffect(() => {
    fetchWarehouses();
    fetchData();
  }, []);

  const getStatus = (item: ReportItem) => {
    if (item.expired) return { icon: 'alert-circle', color: '#ffc107', label: 'Hết hạn' };
    if (item.quantity < item.min_level) return { icon: 'arrow-down-circle', color: '#dc3545', label: 'Tồn thấp' };
    if (item.quantity > item.max_level) return { icon: 'arrow-up-circle', color: '#17a2b8', label: 'Vượt mức' };
    return { icon: 'checkmark-circle', color: '#28a745', label: 'Bình thường' };
  };

  const renderItem = ({ item }: { item: ReportItem }) => {
    const status = getStatus(item);

    return (
      <View style={styles.item}>
        <Ionicons name={status.icon as any} size={24} color={status.color} style={styles.icon} />
        <View style={{ flex: 1 }}>
          <Text style={styles.title}>{item.material_name}</Text>
          <Text style={styles.meta}>Kho: {item.warehouse_name}</Text>
          <Text style={styles.meta}>Tồn: {item.quantity} {item.unit_name} | Min: {item.min_level} | Max: {item.max_level}</Text>
          <Text style={[styles.status, { color: status.color }]}>{status.label}</Text>
        </View>
      </View>
    );
  };

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Báo cáo tồn kho</Text>

      <View style={styles.filterBox}>
        <Text style={styles.label}>Từ ngày</Text>
        <DateTimePicker value={fromDate} mode="date" display="default" onChange={(_, date) => date && setFromDate(date)} />

        <Text style={styles.label}>Đến ngày</Text>
        <DateTimePicker value={toDate} mode="date" display="default" onChange={(_, date) => date && setToDate(date)} />

        <Text style={styles.label}>Kho</Text>
        <View style={styles.pickerWrap}>
          <Picker selectedValue={warehouseId} onValueChange={setWarehouseId}>
            <Picker.Item label="Tất cả kho" value="" />
            {warehouses.map(w => <Picker.Item key={w.id} label={w.name} value={w.id} />)}
          </Picker>
        </View>

        <Text style={styles.label}>Trạng thái</Text>
        <View style={styles.pickerWrap}>
          <Picker selectedValue={statusFilter} onValueChange={setStatusFilter}>
            <Picker.Item label="Tất cả" value="" />
            <Picker.Item label="Tồn thấp" value="low" />
            <Picker.Item label="Vượt mức" value="high" />
            <Picker.Item label="Hết hạn" value="expired" />
          </Picker>
        </View>

        <TouchableOpacity style={styles.button} onPress={fetchData}>
          <Ionicons name="search" size={20} color="#fff" />
          <Text style={styles.buttonText}>Lọc báo cáo</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.exportBtn} onPress={exportCSV}>
          <Ionicons name="download-outline" size={20} color="#fff" />
          <Text style={styles.buttonText}>Xuất CSV</Text>
        </TouchableOpacity>
      </View>

      {loading ? <ActivityIndicator size="large" style={{ marginTop: 100 }} /> : (
        <FlatList
          data={data}
          keyExtractor={(_, index) => index.toString()}
          renderItem={renderItem}
        />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff', padding: 16 },
  header: { fontSize: 20, fontWeight: 'bold', marginBottom: 12 },
  filterBox: { marginBottom: 20 },
  label: { fontWeight: '600', marginTop: 10 },
  pickerWrap: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 6,
    marginBottom: 10,
  },
  button: {
    marginTop: 12,
    backgroundColor: '#007bff',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 10,
    borderRadius: 6,
  },
  exportBtn: {
    marginTop: 10,
    backgroundColor: '#28a745',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 10,
    borderRadius: 6,
  },
  buttonText: { color: '#fff', marginLeft: 6, fontWeight: '600' },
  item: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    backgroundColor: '#f9f9f9',
    padding: 12,
    borderRadius: 8,
    marginBottom: 10,
  },
  icon: { marginRight: 12, marginTop: 4 },
  title: { fontWeight: '600', fontSize: 16 },
  meta: { color: '#555', fontSize: 13 },
  status: { fontSize: 13, marginTop: 4, fontWeight: '600' },
});

export default InventoryReport;
