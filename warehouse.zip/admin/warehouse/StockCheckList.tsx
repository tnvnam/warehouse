import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  FlatList,
  StyleSheet,
  ActivityIndicator,
  Alert,
  TouchableOpacity,
} from 'react-native';
import Ionicons from 'react-native-vector-icons/Ionicons';
import { useNavigation } from '@react-navigation/native';

interface StockCheckItem {
  id: string;
  warehouse_name: string;
  date: string;
  note?: string;
}

const StockCheckList = () => {
  const [data, setData] = useState<StockCheckItem[]>([]);
  const [loading, setLoading] = useState(true);
  const navigation = useNavigation();

  const fetchData = async () => {
    try {
      const res = await fetch('http://10.0.2.2:3000/stockcheck');
      const result = await res.json();
      setData(result);
    } catch {
      Alert.alert('Lỗi', 'Không thể tải danh sách kiểm kê');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const renderItem = ({ item }: { item: StockCheckItem }) => (
    <View style={styles.item}>
      <Ionicons name="clipboard-outline" size={24} color="#17a2b8" style={styles.icon} />
      <View style={{ flex: 1 }}>
        <Text style={styles.title}>Kho: {item.warehouse_name}</Text>
        <Text style={styles.meta}>Ngày kiểm: {item.date}</Text>
        {item.note ? <Text style={styles.meta}>Ghi chú: {item.note}</Text> : null}
      </View>
    </View>
  );

  if (loading) return <ActivityIndicator size="large" style={{ marginTop: 100 }} />;

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Lịch sử kiểm kê kho</Text>
      <FlatList
        data={data}
        keyExtractor={(item) => item.id}
        renderItem={renderItem}
      />
      <TouchableOpacity
        style={styles.addBtn}
        onPress={() => navigation.navigate('StockCheckForm' as never)}
      >
        <Ionicons name="add" size={24} color="#fff" />
        <Text style={styles.addText}>Tạo kiểm kê</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff', padding: 16 },
  header: { fontSize: 20, fontWeight: 'bold', marginBottom: 12 },
  item: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    backgroundColor: '#f5f5f5',
    padding: 12,
    borderRadius: 8,
    marginBottom: 10,
  },
  icon: { marginRight: 12, marginTop: 4 },
  title: { fontWeight: '600', fontSize: 16 },
  meta: { color: '#555', fontSize: 13 },
  addBtn: {
    marginTop: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 12,
    borderRadius: 6,
    backgroundColor: '#17a2b8',
  },
  addText: { color: '#fff', marginLeft: 6, fontWeight: '600' },
});

export default StockCheckList;
