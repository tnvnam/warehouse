import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ActivityIndicator, ScrollView } from 'react-native';
import { RouteProp, useRoute } from '@react-navigation/native';
import type { RootStackParamList } from '../AppNavigator';
import COLORS from '../../theme/theme';

interface Product {
  id: string;
  name: string;
  code: string;
  category: string;
  unit: string;
  price: number;
  description?: string;
  created_at?: string;
}

type ProductDetailRouteProp = RouteProp<RootStackParamList, 'ProductDetail'>;

const ProductDetail: React.FC = () => {
  const route = useRoute<ProductDetailRouteProp>();
  const { id } = route.params;
  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchProduct = async () => {
    try {
      const res = await fetch(`http://10.0.2.2:3000/products/${id}`);
      const data = await res.json();
      setProduct(data);
    } catch (err) {
      console.error('Lỗi tải sản phẩm:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProduct();
  }, [id]);

  if (loading) return <ActivityIndicator style={{ marginTop: 100 }} size="large" />;
  if (!product) return <Text style={{ marginTop: 100, textAlign: 'center' }}>Không tìm thấy sản phẩm</Text>;

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.label}>Tên sản phẩm</Text>
      <Text style={styles.value}>{product.name}</Text>

      <Text style={styles.label}>Mã</Text>
      <Text style={styles.value}>{product.code}</Text>

      <Text style={styles.label}>Danh mục</Text>
      <Text style={styles.value}>{product.category}</Text>

      <Text style={styles.label}>Đơn vị</Text>
      <Text style={styles.value}>{product.unit}</Text>

      <Text style={styles.label}>Giá</Text>
      <Text style={styles.value}>{product.price?.toLocaleString()} đ</Text>

      {product.description && (
        <>
          <Text style={styles.label}>Mô tả</Text>
          <Text style={styles.value}>{product.description}</Text>
        </>
      )}

      {product.created_at && (
        <>
          <Text style={styles.label}>Ngày tạo</Text>
          <Text style={styles.value}>{new Date(product.created_at).toLocaleDateString()}</Text>
        </>
      )}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: '#fff' },
  label: { fontWeight: '600', fontSize: 14, marginTop: 16, color: COLORS.gray },
  value: { fontSize: 16, marginTop: 4, color: COLORS.text },
});

export default ProductDetail;
