// admin/theme.ts
const COLORS = {
  primary: '#28a745',
  primaryDark: '#1e7e34',
  white: '#ffffff',
  gray: '#ccc',
  text: '#333',
  danger: '#dc3545',
  grayLight: '#f5f5f5'
};


export default COLORS;
